# 5thSem_Express_Assignment
This Repository is about the backend implimentation for authors and blogs information.

| Action | Path |
| ------ | ------ |
| Register |```http://localhost:3000/author/register``` |
| Login | ```http://localhost:3000/author/login```|
| Create Blogs | ```http://localhost:3000/blog/createBlogs``` |
| Get All Blogs | ```http://localhost:3000/blog/getAllBlogs``` |
| Get Authors Blogs | ```http://localhost:3000/blog/getBlogs/101``` |
